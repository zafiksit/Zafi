API_TOKEN = '5002979640:AAGbB2l7p2w64C_MMx8uSzyLj96RWWfx0WY/test'

admin = [2200034733]
start_money = 10000

bot_name = 'ZFG'
chat = 't.me/+B_ohObJJ11UyN2Ey'
channel = 't.me/zafi_vf'
admin_username = '@senko_san'
bot_username = 'zfgbot'

chat_log = -1002200626811
cleaning = 60

custom_modules = True