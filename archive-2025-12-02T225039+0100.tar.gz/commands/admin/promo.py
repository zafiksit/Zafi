import random

from datetime import datetime

from aiogram import types

from aiogram.filters import Command

from aiogram.fsm.context import FSMContext

from aiogram.utils.keyboard import InlineKeyboardBuilder

from assets.antispam import admin_only

from assets.transform import transform_int

from filters.custom import TextIn

from states.admin import NewPromoState, DellPromoState, PromoInfoState

from commands.admin.db import (

    add_promo_db,

    del_promo_db,

    get_promo_data_db,   # ← добавлено

    get_users_chats

)

from bot import bot


@admin_only(private=True)
async def promo_menu(message: types.Message):
    await message.answer("👾 Выберите действие:", reply_markup=kb.promo_menu())


@admin_only(private=True)
async def new_promo(message, state: FSMContext):
    current = await state.get_state()

    if message.text == "Отмена":
        await state.clear()
        await promo_menu(message)
        return

    if not current:
        await message.answer("😄 Введите название промо", reply_markup=kb.cancel())
        await state.set_state(NewPromoState.txt)
        return

    if current == NewPromoState.txt:
        await state.update_data(name=message.text.split()[0])
        await message.answer("📟 Введите валюту которую будет выдавать промокод (таблица/столбик эмодзи)\n\n"
                             "Пример для промо на йены: <code>users/yen 💴</code>\n\n"
                             "<i>Для создания промокода на деньги используйте \"-\"</i>")
        await state.set_state(NewPromoState.summ)
        return

    if current == NewPromoState.summ:
        txt = "users/balance $" if message.text == "-" else message.text
        await state.update_data(txt=txt)
        await message.answer("😃 Введите сумму $ за активацию")
        await state.set_state(NewPromoState.activ)
        return

    try:
        summ = message.text.split()[0].replace("е", "e")
        summ = int(float(summ))
    except:
        await message.answer("😔 Значение должно быть числом...")
        return

    if current == NewPromoState.activ:
        await state.update_data(summ=summ)
        await message.answer("😊 Введите количество активаций")
        await state.set_state(NewPromoState.count)
        return

    if current == NewPromoState.count:
        await state.update_data(count=summ)
        await message.answer("🔔 Промокод требует подписку на канал?\n\n"
                             "1 - Да (обязательная подписка)\n"
                             "2 - Нет (без обязательной подписки)",
                             reply_markup=kb.cancel())
        await state.set_state(NewPromoState.require_sub)
        return

    if current == NewPromoState.require_sub:
        if message.text == "1":
            await state.update_data(require_sub=1)
        elif message.text == "2":
            await state.update_data(require_sub=0)
        else:
            await message.answer("❌ Пожалуйста, выберите 1 или 2")
            return

        # Завершение создания промокода
        data = await state.get_data()
        await state.clear()

        # Добавляем require_sub в данные
        data2 = (data["name"], data["summ"], data["count"], data["txt"], data.get("require_sub", 0))
        
        if (await new_promo_db(data2)):
            await message.answer("⚠️ Промокод с таким названием уже существует.")
            await admin_menu_cmd(message)
            return

        summ = tr(data["summ"])
        summ2 = tr(int(data["summ"] * data["count"]))
        count = tr(data["count"])
        emj = " ".join(data["txt"].split()[1:])
        sub_required = "Да" if data.get("require_sub", 0) == 1 else "Нет"

        await message.answer(f"""🎰 Вы успешно создали промокод:

Название: <code>{data["name"]}</code>
Сумма: {summ}{emj}
Активаций: {count}
Требует подписку: {sub_required}

Общая сумма: {summ2}{emj}""")
        await admin_menu_cmd(message)
        return


@admin_only(private=True)
async def promo_info(message, state: FSMContext):
    current = await state.get_state()

    if message.text == "Отмена":
        await state.clear()
        await promo_menu(message)
        return

    if not current:
        await message.answer("💻 Введите название промо", reply_markup=kb.cancel())
        await state.set_state(PromoInfoState.name)
        return

    name = message.text.split()[0]
    res = await promo_info_db(name)
    
    if not res:
        await message.answer(f"❌ Промокод <b>{name}</b> не найден.")
    else:
        summ = tr(int(res[1]))
        emj = " ".join(res[3].split()[1:])
        sub_required = "Да" if len(res) > 4 and res[4] == 1 else "Нет"
        
        await message.answer(f"""🎰 Информация о промокоде:

Название: <code>{res[0]}</code>
Сумма: {summ}{emj}
Осталось активаций: {res[2]}
Требует подписку: {sub_required}""")
    await state.clear()
    await promo_menu(message)


@admin_only(private=True)
async def dell_promo(message, state: FSMContext):
    current = await state.get_state()

    if message.text == "Отмена":
        await state.clear()
        await promo_menu(message)
        return

    if not current:
        await message.answer("🗑 Введите название промо который вы хотите удалить", reply_markup=kb.cancel())
        await state.set_state(DellPromoState.name)
        return

    name = message.text.split()[0]
    res = await dell_promo_db(name)

    if res:
        await message.answer(f"❌ Промокод <b>{name}</b> не найден.")
    else:
        await message.answer(f"✅ Промокод <b>{name}</b> успешно удалён!")

    await state.clear()
    await promo_menu(message)


@antispam
async def activ_promo(message: types.Message, user: BFGuser):
    win, lose = BFGconst.emj()
    
    if len(message.text.split()) < 2:
        await message.answer(f"Вы не ввели промокод {lose}")
        return
    
    name = message.text.split()[1]
    res = await activ_promo_db(name, user.id)

    if res == "no promo":
        await message.answer(f"Данного промокода не существует {lose}\n\n{BFGconst.ads}")
        return

    if res == "activated":
        await message.answer(f"Данный промокод уже активирован {lose}\n\n{BFGconst.ads}")
        return

    if res == "used":
        await message.answer(f"Вы уже активировали этот промокод {lose}\n\n{BFGconst.ads}")
        return

    # Проверка подписки если требуется
    promo_data = await get_promo_data_db(name)
    if promo_data and len(promo_data) > 4 and promo_data[4] == 1:  # require_sub = 1
        try:
            channel = await bot.get_chat_member(
                chat_id="@"+cfg.channel.replace("t.me/", ""), 
                user_id=message.from_user.id
            )
            
            if channel["status"] in ["left", "kicked"]:
                await message.answer(f"Для активации промокода вам надо подписаться на <a href='{cfg.channel}'>официальный канал бота</a> {lose}\n\n{BFGconst.ads}")
                return
        except Exception as e:
            print(f"Ошибка проверки подписки на канал {e}")
            await message.answer(f"Ошибка проверки подписки. Попробуйте позже {lose}")
            return

    summ = tr(int(res[1]))
    emj = " ".join(res[3].split()[1:])

    await new_log(f"#промоактив\nИгрок: {message.from_user.id}\nПромо: {name}\nСумма: {summ}{emj}", "promo")
    await message.answer(f"{user.url}, вы активировали промокод <b>{res[0]}</b>!\nПолучено: <b>{summ}</b>{emj} {win}")


def reg(dp: Dispatcher):
    dp.message.register(promo_menu, TextIn("✨ Промокоды"))

    dp.message.register(promo_info, TextIn("ℹ️ Промо инфо"))
    dp.message.register(promo_info, PromoInfoState.name)

    dp.message.register(new_promo, TextIn("📖 Создать промо"))
    dp.message.register(new_promo, StateFilter(NewPromoState.txt, NewPromoState.name, NewPromoState.summ, 
                                              NewPromoState.activ, NewPromoState.count, NewPromoState.require_sub))

    dp.message.register(dell_promo, TextIn("🗑 Удалить промо"))
    dp.message.register(dell_promo, DellPromoState.name)

    dp.message.register(activ_promo, StartsWith("промо"))