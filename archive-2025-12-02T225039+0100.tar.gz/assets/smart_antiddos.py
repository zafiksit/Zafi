import time, asyncio
TRAFFIC_WINDOW=1; TRAFFIC_LOG=[]; LOCKDOWN=False; QUARANTINE=set(); USER_LOG={}; ADMINS=set()
MAX_RPS=40; MAX_USER_RPS=2; TASK_LIMIT=12; sema=asyncio.Semaphore(TASK_LIMIT)
def detect_ddos():
    global LOCKDOWN
    now=time.time(); TRAFFIC_LOG.append(now)
    while TRAFFIC_LOG and now-TRAFFIC_LOG[0]>TRAFFIC_WINDOW: TRAFFIC_LOG.pop(0)
    if len(TRAFFIC_LOG)>MAX_RPS: LOCKDOWN=True
    return LOCKDOWN
def user_should_block(uid):
    if uid in QUARANTINE: return True
    if LOCKDOWN and uid not in ADMINS: return True
    now=time.time(); lst=USER_LOG.get(uid,[]); lst.append(now)
    USER_LOG[uid]=[t for t in lst if now-t<=1]
    if len(USER_LOG[uid])>=MAX_USER_RPS: QUARANTINE.add(uid); return True
    return False
def adaptive(mem):
    global MAX_RPS,TASK_LIMIT,sema
    if mem>85: MAX_RPS=max(10,MAX_RPS-10); TASK_LIMIT=max(2,TASK_LIMIT-2)
    elif mem<50: MAX_RPS=min(80,MAX_RPS+1); TASK_LIMIT=min(25,TASK_LIMIT+1)
    sema=asyncio.Semaphore(TASK_LIMIT)
